Nama : Shirleen Adriana\
NIM : 230401010109\
Kelas : IT104\
Mata Kuliah : Algoritma dan Pemrograman

# Hasil Nomor 1:

![Screenshot](Tugas_1.png)

# Hasil Nomor 2:

![Screenshot](Tugas_2.png)

# Hasil Nomor 3:

![Screenshot](Tugas_3.png)
